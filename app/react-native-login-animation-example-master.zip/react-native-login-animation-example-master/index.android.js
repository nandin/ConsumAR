import { AppRegistry } from 'react-native'
import LoginAnimation from './src/app'

AppRegistry.registerComponent('LoginAnimation', () => LoginAnimation)

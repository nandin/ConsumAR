import Home from './Home';
import Login from './Login';
import Register from './Register';

export {Home, Login, Register}
export default {Home, Login, Register}
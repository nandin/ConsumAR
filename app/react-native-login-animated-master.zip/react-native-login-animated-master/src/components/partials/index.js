import AlertStatus from './AlertStatus';
import BackgroundWrapper from './BackgroundWrapper';
import Logo from './Logo';

export {
    AlertStatus, BackgroundWrapper, Logo
}

export default {
    AlertStatus, BackgroundWrapper, Logo
}
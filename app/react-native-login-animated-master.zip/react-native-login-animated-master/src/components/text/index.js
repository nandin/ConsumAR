import Heading from './Heading';
import TextFont from './TextFont';

export {
    Heading, TextFont
}

export default {
    Heading, TextFont
}